using System;
using System.Net;
using System.Net.Sockets;
using ZeroTier.Sockets;

namespace PCL2.Modules.Network
{
    public class ZeroTierManager
    {
        private static ZTService _service;
        private static string _networkId;

        public static void Initialize()
        {
            if (_service == null)
            {
                _service = new ZTService();
                _service.Start("pcl2pro_network");
            }
        }

        public static string CreateNetwork()
        {
            Initialize();
            _networkId = GenerateNetworkId();
            _service.CreateNetwork(_networkId);
            return _networkId;
        }

        public static void JoinNetwork(string networkId)
        {
            Initialize();
            _service.Join(networkId);
            _networkId = networkId;
            StartPlayerDiscovery();
        }

        private static void StartPlayerDiscovery()
        {
            // ����UDP�����߳�
            new System.Threading.Thread(() =>
            {
                using (var udpClient = new UdpClient(19132))
                {
                    IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, 0);

                    while (true)
                    {
                        try
                        {
                            byte[] data = udpClient.Receive(ref endPoint);
                            string message = System.Text.Encoding.UTF8.GetString(data);

                            if (message.StartsWith("PCL2PRO_DISCOVERY"))
                            {
                                // ����������Ϣ
                                OnPlayerDiscovered(endPoint.Address.ToString());
                            }
                        }
                        catch (SocketException)
                        {
                            // �����˳�
                            break;
                        }
                    }
                }
            }).Start();
        }

        public static event Action<string> PlayerDiscovered;

        private static void OnPlayerDiscovered(string ip)
        {
            PlayerDiscovered?.Invoke(ip);
        }

        private static string GenerateNetworkId()
        {
            var random = new Random();
            const string chars = "0123456789abcdef";
            return new string(Enumerable.Repeat(chars, 24)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}