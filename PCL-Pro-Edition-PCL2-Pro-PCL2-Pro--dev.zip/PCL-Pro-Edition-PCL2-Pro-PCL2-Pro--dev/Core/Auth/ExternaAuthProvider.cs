using System;
using System.Collections.Generic;
using System.Net.Http;
using Newtonsoft.Json;

namespace PCL2.Core.Auth
{
    public class ExternalAuthProvider
    {
        private static readonly Dictionary<string, string> PredefinedEndpoints = new Dictionary<string, string>
        {
            ["littleskin"] = "https://littleskin.cn/api/yggdrasil",
            ["redstone"] = "https://skin.redstone.ren/api/yggdrasil"
        };

        public static AuthResult Authenticate(string endpointKey, string username, string password)
        {
            string endpoint = PredefinedEndpoints.ContainsKey(endpointKey)
                ? PredefinedEndpoints[endpointKey]
                : endpointKey;

            return AuthenticateWithYggdrasil(endpoint, username, password);
        }

        private static AuthResult AuthenticateWithYggdrasil(string baseUrl, string username, string password)
        {
            using (var client = new HttpClient())
            {
                var authRequest = new
                {
                    agent = new { name = "Minecraft", version = 1 },
                    username,
                    password,
                    clientToken = Guid.NewGuid().ToString()
                };

                var response = client.PostAsync($"{baseUrl}/authenticate",
                    new StringContent(JsonConvert.SerializeObject(authRequest))).Result;

                if (!response.IsSuccessStatusCode)
                {
                    return new AuthResult { Success = false, Error = "Authentication failed" };
                }

                var authData = JsonConvert.DeserializeObject<dynamic>(response.Content.ReadAsStringAsync().Result);

                return new AuthResult
                {
                    Success = true,
                    Username = authData.selectedProfile.name,
                    UUID = authData.selectedProfile.id,
                    AccessToken = authData.accessToken,
                    SkinUrl = $"{baseUrl}/session/minecraft/profile/{authData.selectedProfile.id}"
                };
            }
        }
    }

    public class AuthResult
    {
        public bool Success { get; set; }
        public string Username { get; set; }
        public string UUID { get; set; }
        public string AccessToken { get; set; }
        public string SkinUrl { get; set; }
        public string Error { get; set; }
    }
}