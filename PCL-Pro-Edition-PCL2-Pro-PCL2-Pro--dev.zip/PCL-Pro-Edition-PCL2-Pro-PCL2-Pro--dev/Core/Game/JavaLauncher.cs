// ��JavaLauncher�����������·���

private void PrepareRiftLoader(string versionPath)
{
    string riftVersion = "1.13.2";
    string riftPath = Path.Combine(versionPath, $"rift-{riftVersion}.jar");

    if (!File.Exists(riftPath))
    {
        DownloadRiftLoader(riftPath, riftVersion);
    }

    // ����Rift��classpath
    AddToClassPath(riftPath);
}

private void DownloadRiftLoader(string targetPath, string version)
{
    string riftUrl = $"https://github.com/Chocohead/Rift/releases/download/v{version}/rift.jar";

    using (var client = new WebClient())
    {
        client.DownloadFile(riftUrl, targetPath);
    }
}