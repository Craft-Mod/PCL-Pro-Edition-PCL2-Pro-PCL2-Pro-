using System.Diagnostics;
using System.IO;
using Newtonsoft.Json.Linq;

namespace PCL2.Core.Game
{
    public class BedrockLauncher
    {
        public static void Launch(string versionPath, string playerName)
        {
            // ����Ƿ�ΪUWP�汾
            if (IsUWPInstalled())
            {
                LaunchUWP(versionPath, playerName);
            }
            else
            {
                LaunchStandalone(versionPath, playerName);
            }
        }

        private static void LaunchUWP(string versionPath, string playerName)
        {
            // ��ȡUWP��װ·��
            string installPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Packages\\Microsoft.MinecraftUWP_8wekyb3d8bbwe");

            // ������Դ��
            ConfigureResourcePacks(installPath, versionPath);

            // ������Ϸ
            Process.Start("minecraft://");
        }

        private static void ConfigureResourcePacks(string installPath, string resourcePackPath)
        {
            string configPath = Path.Combine(installPath, "LocalState\\game_launcher_settings.json");

            if (!File.Exists(configPath)) return;

            var config = JObject.Parse(File.ReadAllText(configPath));
            var resourcePacks = config["resource_packs"] as JArray ?? new JArray();

            // ��������Դ��
            if (!resourcePacks.Contains(resourcePackPath))
            {
                resourcePacks.Add(resourcePackPath);
                config["resource_packs"] = resourcePacks;
                File.WriteAllText(configPath, config.ToString());
            }
        }

        private static void LaunchStandalone(string versionPath, string playerName)
        {
            string exePath = Path.Combine(versionPath, "bedrock_server.exe");

            if (!File.Exists(exePath))
            {
                throw new FileNotFoundException("Bedrock server executable not found");
            }

            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = exePath,
                Arguments = $"-player \"{playerName}\"",
                UseShellExecute = false
            };

            Process.Start(startInfo);
        }

        private static bool IsUWPInstalled()
        {
            // ���UWP�汾�Ƿ�װ
            string uwpPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Packages\\Microsoft.MinecraftUWP_8wekyb3d8bbwe");

            return Directory.Exists(uwpPath);
        }
    }
}